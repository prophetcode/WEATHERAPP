const apiKey = '29cd18cbbacf789119c6595b348e00b9'; // Replace with your API key
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

function fetchWeatherData(city) {
  const url = `${apiUrl}?q=${city}&appid=${apiKey}&units=metric`;

  return fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error('Request failed with status: ' + response.status);
      }
      return response.json();//clean up
    })
    .catch(error => {
      console.log('Error occurred during API request:', error);
    });
}

function displayWeatherData(data) {
  const weatherInfo = document.getElementById('weather-info');
  weatherInfo.innerHTML = '';

  const cityName = document.createElement('h2');
  cityName.textContent = data.name;
  weatherInfo.appendChild(cityName);

  const temperature = document.createElement('p');
  temperature.textContent = 'Temperature: ' + data.main.temp + ' °C';
  weatherInfo.appendChild(temperature);

  const weatherDescription = document.createElement('p');
  weatherDescription.textContent = 'Description: ' + data.weather[0].description;
  weatherInfo.appendChild(weatherDescription);
}

// Example usage:
const city = 'Lagos';
fetchWeatherData(city)
  .then(data => {
    displayWeatherData(data);
  })
  .catch(error => {
    console.log('Failed to fetch weather data:', error);
  });











